"""
CryptoSteg - Cryptographic Operations Module
Handles PKI infrastructure, RSA key generation, AES encryption, and digital signatures
"""

import os
import json
import hashlib
import secrets
from datetime import datetime, timedelta
from cryptography.hazmat.primitives import hashes, serialization, padding
from cryptography.hazmat.primitives.asymmetric import rsa, padding as asym_padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import base64

class PKIManager:
    """Public Key Infrastructure Manager for CryptoSteg"""
    
    def __init__(self):
        self.users_db = {}
        self.crl = set()  # Certificate Revocation List
        self.sessions = {}
        self.data_dir = "pki_data"
        os.makedirs(self.data_dir, exist_ok=True)
        self.load_data()
    
    def generate_rsa_keypair(self):
        """Generate 2048-bit RSA key pair"""
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )
        public_key = private_key.public_key()
        return private_key, public_key
    
    def serialize_key(self, key, is_private=False):
        """Serialize key to PEM format"""
        if is_private:
            return key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
        else:
            return key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
    
    def deserialize_key(self, key_data, is_private=False):
        """Deserialize key from PEM format"""
        if is_private:
            return serialization.load_pem_private_key(
                key_data, password=None, backend=default_backend()
            )
        else:
            return serialization.load_pem_public_key(
                key_data, backend=default_backend()
            )
    
    def register_user(self, username):
        """Register new user with RSA key pair and session token"""
        if username in self.users_db:
            return False, "User already exists"
        
        # Generate RSA key pair
        private_key, public_key = self.generate_rsa_keypair()
        
        # Generate session token
        session_token = secrets.token_urlsafe(32)
        
        # Store user data
        user_data = {
            'username': username,
            'private_key': self.serialize_key(private_key, is_private=True).decode(),
            'public_key': self.serialize_key(public_key).decode(),
            'session_token': session_token,
            'created_at': datetime.now().isoformat(),
            'revoked': False
        }
        
        self.users_db[username] = user_data
        self.sessions[session_token] = username
        self.save_data()
        
        return True, session_token
    
    def authenticate_user(self, token):
        """Authenticate user by session token and check CRL"""
        if token not in self.sessions:
            return False, "Invalid token"
        
        username = self.sessions[token]
        if username in self.crl:
            return False, "User revoked"
        
        return True, username
    
    def revoke_user(self, username):
        """Add user to Certificate Revocation List"""
        if username in self.users_db:
            self.crl.add(username)
            self.users_db[username]['revoked'] = True
            self.save_data()
            return True
        return False
    
    def get_user_keys(self, username):
        """Get user's RSA key pair"""
        if username not in self.users_db:
            return None, None
        
        user_data = self.users_db[username]
        private_key = self.deserialize_key(user_data['private_key'].encode(), is_private=True)
        public_key = self.deserialize_key(user_data['public_key'].encode())
        
        return private_key, public_key
    
    def encrypt_message(self, message, sender_username, recipient_username=None):
        """Encrypt message with AES-256-CBC and sign with sender's private key"""
        # Generate AES key and IV
        aes_key = os.urandom(32)  # 256-bit key
        iv = os.urandom(16)  # 128-bit IV
        
        # Pad message to AES block size
        padder = padding.PKCS7(128).padder()
        padded_message = padder.update(message.encode()) + padder.finalize()
        
        # Encrypt with AES
        cipher = Cipher(algorithms.AES(aes_key), modes.CBC(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        encrypted_message = encryptor.update(padded_message) + encryptor.finalize()
        
        # Sign the original message with sender's private key
        sender_private_key, _ = self.get_user_keys(sender_username)
        signature = sender_private_key.sign(
            message.encode(),
            asym_padding.PSS(
                mgf=asym_padding.MGF1(hashes.SHA256()),
                salt_length=asym_padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        
        # Create payload
        payload = {
            'encrypted_message': base64.b64encode(encrypted_message).decode(),
            'aes_key': base64.b64encode(aes_key).decode(),
            'iv': base64.b64encode(iv).decode(),
            'signature': base64.b64encode(signature).decode(),
            'sender': sender_username,
            'timestamp': datetime.now().isoformat()
        }
        
        return json.dumps(payload)
    
    def decrypt_message(self, encrypted_payload):
        """Decrypt message and verify signature"""
        try:
            payload = json.loads(encrypted_payload)
            
            # Extract components
            encrypted_message = base64.b64decode(payload['encrypted_message'])
            aes_key = base64.b64decode(payload['aes_key'])
            iv = base64.b64decode(payload['iv'])
            signature = base64.b64decode(payload['signature'])
            sender = payload['sender']
            
            # Decrypt with AES
            cipher = Cipher(algorithms.AES(aes_key), modes.CBC(iv), backend=default_backend())
            decryptor = cipher.decryptor()
            padded_message = decryptor.update(encrypted_message) + decryptor.finalize()
            
            # Remove padding
            unpadder = padding.PKCS7(128).unpadder()
            message = unpadder.update(padded_message) + unpadder.finalize()
            
            # Verify signature
            _, sender_public_key = self.get_user_keys(sender)
            sender_public_key.verify(
                signature,
                message,
                asym_padding.PSS(
                    mgf=asym_padding.MGF1(hashes.SHA256()),
                    salt_length=asym_padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            
            return True, message.decode(), sender
            
        except Exception as e:
            return False, f"Decryption failed: {str(e)}", None
    
    def get_stats(self):
        """Get PKI statistics for admin panel"""
        return {
            'total_users': len(self.users_db),
            'active_users': len([u for u in self.users_db.values() if not u['revoked']]),
            'revoked_users': len(self.crl),
            'active_sessions': len(self.sessions)
        }
    
    def save_data(self):
        """Save PKI data to disk"""
        data = {
            'users_db': self.users_db,
            'crl': list(self.crl),
            'sessions': self.sessions
        }
        with open(os.path.join(self.data_dir, 'pki_data.json'), 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_data(self):
        """Load PKI data from disk"""
        try:
            with open(os.path.join(self.data_dir, 'pki_data.json'), 'r') as f:
                data = json.load(f)
                self.users_db = data.get('users_db', {})
                self.crl = set(data.get('crl', []))
                self.sessions = data.get('sessions', {})
        except FileNotFoundError:
            pass

# Global PKI instance
pki_manager = PKIManager()