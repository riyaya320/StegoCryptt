"""
CryptoSteg - Admin Interface
Real-time monitoring panel with WebSocket support
"""

from flask import Flask, render_template
from flask_socketio import SocketIO, emit
import threading
import time
import json
from crypto import pki_manager

admin_app = Flask(__name__)
admin_app.config['SECRET_KEY'] = 'cryptosteg_admin_secret_2023'
socketio = SocketIO(admin_app, cors_allowed_origins="*")

class AdminMonitor:
    """Real-time monitoring system for CryptoSteg"""
    
    def __init__(self):
        self.monitoring = False
        self.monitor_thread = None
    
    def start_monitoring(self):
        """Start real-time monitoring"""
        if not self.monitoring:
            self.monitoring = True
            self.monitor_thread = threading.Thread(target=self._monitor_loop)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
    
    def stop_monitoring(self):
        """Stop monitoring"""
        self.monitoring = False
    
    def _monitor_loop(self):
        """Main monitoring loop"""
        while self.monitoring:
            try:
                # Get current stats
                stats = pki_manager.get_stats()
                
                # Add additional monitoring data
                monitoring_data = {
                    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'pki_stats': stats,
                    'system_status': 'operational',
                    'active_processes': {
                        'main_app': True,
                        'admin_panel': True,
                        'pki_manager': True,
                        'stego_engine': True
                    },
                    'security_alerts': self._check_security_alerts(),
                    'user_list': self._get_user_summary()
                }
                
                # Emit to all connected admin clients
                socketio.emit('monitoring_update', monitoring_data)
                
                time.sleep(2)  # Update every 2 seconds
                
            except Exception as e:
                print(f"Monitoring error: {e}")
                time.sleep(5)
    
    def _check_security_alerts(self):
        """Check for security alerts"""
        alerts = []
        
        # Check for recently revoked users
        if len(pki_manager.crl) > 0:
            alerts.append({
                'level': 'warning',
                'message': f'{len(pki_manager.crl)} user(s) currently revoked',
                'timestamp': time.strftime('%H:%M:%S')
            })
        
        # Check for high user activity
        if len(pki_manager.sessions) > 10:
            alerts.append({
                'level': 'info',
                'message': f'High activity: {len(pki_manager.sessions)} active sessions',
                'timestamp': time.strftime('%H:%M:%S')
            })
        
        return alerts
    
    def _get_user_summary(self):
        """Get summary of registered users"""
        users = []
        for username, user_data in pki_manager.users_db.items():
            users.append({
                'username': username,
                'status': 'revoked' if user_data['revoked'] else 'active',
                'created': user_data['created_at'][:10],  # Date only
                'has_session': user_data['session_token'] in pki_manager.sessions
            })
        return users[:10]  # Limit to 10 most recent

# Global monitor instance
admin_monitor = AdminMonitor()

@admin_app.route('/admin')
def admin_panel():
    """Admin panel interface"""
    return render_template('admin.html')

@socketio.on('connect')
def handle_connect():
    """Handle admin client connection"""
    print('Admin client connected')
    admin_monitor.start_monitoring()
    emit('connection_status', {'status': 'connected', 'message': 'Admin panel connected'})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle admin client disconnection"""
    print('Admin client disconnected')

@socketio.on('request_stats')
def handle_stats_request():
    """Handle manual stats request"""
    stats = pki_manager.get_stats()
    emit('stats_update', stats)

@socketio.on('revoke_user_admin')
def handle_admin_revoke(data):
    """Handle user revocation from admin panel"""
    username = data.get('username')
    if username:
        success = pki_manager.revoke_user(username)
        emit('revoke_result', {
            'success': success,
            'username': username,
            'message': f'User {username} {"revoked" if success else "not found"}'
        })

if __name__ == '__main__':
    print("🔧 CryptoSteg Admin Panel")
    print("📊 Real-time monitoring available at http://localhost:5001/admin")
    
    # Get and display the actual IP address
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        print(f"📱 Admin panel network access: http://{local_ip}:5001/admin")
    except Exception as e:
        print(f"⚠️  Could not determine IP address: {e}")
    
    try:
        socketio.run(admin_app, debug=True, host='0.0.0.0', port=5001, allow_unsafe_werkzeug=True)
    except Exception as e:
        print(f"❌ Failed to start admin server: {e}")
        print("🔧 Trying alternative configuration...")
        socketio.run(admin_app, debug=True, host='127.0.0.1', port=5001, allow_unsafe_werkzeug=True)