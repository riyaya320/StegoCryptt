"""
CryptoSteg - Steganography Module
Implements LSB steganography with seed-based randomization and checksum validation
"""

import hashlib
import random
import json
from PIL import Image
import io
import base64

class SteganographyEngine:
    """Advanced LSB Steganography with randomization and integrity checking"""
    
    def __init__(self):
        self.delimiter = "<<<CRYPTOSTEG_END>>>"
    
    def generate_seed(self, username):
        """Generate deterministic seed from username hash"""
        return int(hashlib.sha256(username.encode()).hexdigest()[:8], 16)
    
    def calculate_checksum(self, data):
        """Calculate SHA-256 checksum for data integrity"""
        return hashlib.sha256(data.encode()).hexdigest()
    
    def embed_message(self, image_path, message, username):
        """Embed encrypted message into image using LSB with randomization"""
        try:
            # Open and convert image to RGB
            img = Image.open(image_path)
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Calculate checksum
            checksum = self.calculate_checksum(message)
            
            # Prepare payload with checksum and delimiter
            payload = f"{checksum}|{message}{self.delimiter}"
            
            # Convert to binary
            binary_payload = ''.join(format(ord(char), '08b') for char in payload)
            
            # Check if image can hold the message
            img_width, img_height = img.size
            max_capacity = img_width * img_height * 3  # 3 channels (RGB)
            
            if len(binary_payload) > max_capacity:
                return False, "Image too small for message"
            
            # Generate randomized pixel positions using username seed
            seed = self.generate_seed(username)
            random.seed(seed)
            
            # Create list of all pixel positions
            positions = []
            for y in range(img_height):
                for x in range(img_width):
                    for channel in range(3):  # RGB channels
                        positions.append((x, y, channel))
            
            # Shuffle positions based on seed
            random.shuffle(positions)
            
            # Convert image to list for modification
            pixels = list(img.getdata())
            
            # Embed message bits
            for i, bit in enumerate(binary_payload):
                if i >= len(positions):
                    break
                
                x, y, channel = positions[i]
                pixel_index = y * img_width + x
                pixel = list(pixels[pixel_index])
                
                # Modify LSB of the specified channel
                pixel[channel] = (pixel[channel] & 0xFE) | int(bit)
                pixels[pixel_index] = tuple(pixel)
            
            # Create new image with modified pixels
            stego_img = Image.new('RGB', (img_width, img_height))
            stego_img.putdata(pixels)
            
            return True, stego_img
            
        except Exception as e:
            return False, f"Embedding failed: {str(e)}"
    
    def extract_message(self, image_path, username):
        """Extract message from stego image using username seed"""
        try:
            # Open image
            img = Image.open(image_path)
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            img_width, img_height = img.size
            
            # Generate same randomized positions using username seed
            seed = self.generate_seed(username)
            random.seed(seed)
            
            positions = []
            for y in range(img_height):
                for x in range(img_width):
                    for channel in range(3):
                        positions.append((x, y, channel))
            
            random.shuffle(positions)
            
            # Extract bits
            pixels = list(img.getdata())
            binary_message = ""
            
            for x, y, channel in positions:
                pixel_index = y * img_width + x
                pixel = pixels[pixel_index]
                
                # Extract LSB
                bit = pixel[channel] & 1
                binary_message += str(bit)
                
                # Check for delimiter in extracted text
                if len(binary_message) % 8 == 0:
                    # Convert binary to text
                    chars = []
                    for i in range(0, len(binary_message), 8):
                        byte = binary_message[i:i+8]
                        if len(byte) == 8:
                            chars.append(chr(int(byte, 2)))
                    
                    current_text = ''.join(chars)
                    if self.delimiter in current_text:
                        # Found delimiter, extract message
                        message_with_checksum = current_text.split(self.delimiter)[0]
                        
                        if '|' in message_with_checksum:
                            stored_checksum, message = message_with_checksum.split('|', 1)
                            
                            # Verify checksum
                            calculated_checksum = self.calculate_checksum(message)
                            if stored_checksum == calculated_checksum:
                                return True, message
                            else:
                                return False, "Checksum verification failed"
                        else:
                            return False, "Invalid message format"
            
            return False, "No hidden message found"
            
        except Exception as e:
            return False, f"Extraction failed: {str(e)}"
    
    def get_image_capacity(self, image_path):
        """Calculate maximum message capacity for an image"""
        try:
            img = Image.open(image_path)
            width, height = img.size
            # 3 bits per pixel (RGB), 8 bits per character
            max_chars = (width * height * 3) // 8
            return max_chars - len(self.delimiter) - 64  # Reserve space for checksum and delimiter
        except:
            return 0

# Global steganography instance
stego_engine = SteganographyEngine()

# Ensure the instance is available for import
__all__ = ['stego_engine', 'SteganographyEngine']