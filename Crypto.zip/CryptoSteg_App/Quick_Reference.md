# CryptoSteg - Quick Reference Guide

## Starting the Application

### Option 1: Use the launcher (Recommended)
```bash
cd CryptoSteg_App
python run_cryptosteg.py
```

### Option 2: Manual start
```bash
# Terminal 1 - Main App
cd CryptoSteg_App
python app.py

# Terminal 2 - Admin Panel
cd CryptoSteg_App
python admin.py
```

## Access URLs
- **Main App**: http://localhost:5000
- **Admin Panel**: http://localhost:5001/admin
- **Network Access**: http://[YOUR_IP]:5000 (for mobile QR scanning)

## Default Registration Codes
```
ALPHA-7X9K-DELTA-3M8P
BRAVO-2N5Q-ECHO-7R4T
CHARLIE-9W6E-FOXTROT-1Y8U
DELTA-4H3J-GOLF-6K9L
ECHO-8V2B-HOTEL-5N7M
```

## Common Issues & Solutions

### Template Not Found Error
```bash
# Fix: Recreate templates directory
mkdir -p templates
# Then copy all HTML files from Templates/ to templates/
```

### QR Code Not Scanning on Phone
1. Check if phone and computer are on same WiFi network
2. Find your computer's IP address:
   ```bash
   python network_test.py
   ```
3. If using VM, set network adapter to "Bridged Mode"
4. Check firewall settings

### Port Already in Use
```bash
# Kill processes on ports 5000/5001
sudo lsof -ti:5000 | xargs kill -9
sudo lsof -ti:5001 | xargs kill -9
```

## Testing Features

### Test CRL Functionality
```bash
python test_crl.py
```

### Test Network Connectivity
```bash
python network_test.py
```

## Key Features Implemented

✅ **PKI Infrastructure**: RSA-2048 key generation
✅ **AES-256 Encryption**: CBC mode with PKCS7 padding
✅ **Digital Signatures**: RSA-PSS with SHA-256
✅ **LSB Steganography**: Randomized pixel embedding
✅ **CRL (Certificate Revocation List)**: Real-time user revocation
✅ **QR Code Generation**: Dynamic URL creation
✅ **Admin Panel**: Real-time monitoring with WebSocket
✅ **Authentication System**: Session-based with registration codes

## File Structure
```
CryptoSteg_App/
├── app.py              # Main Flask application
├── admin.py            # Admin panel with WebSocket
├── auth.py             # Authentication system
├── crypto.py           # PKI and cryptographic operations
├── stego.py            # Steganography engine
├── run_cryptosteg.py   # Application launcher
├── templates/          # HTML templates
├── static/             # Static files and stego images
├── uploads/            # Temporary file storage
├── pki_data/           # PKI database
└── auth_data/          # Authentication database
```

## Dependencies
```bash
pip install flask pillow cryptography qrcode[pil] flask-socketio python-socketio
```

## Security Notes
- All messages are encrypted with AES-256
- Digital signatures ensure message authenticity
- CRL provides immediate access revocation
- Session tokens expire after 8 hours
- Failed login attempts trigger account lockout

## Academic Context
This project demonstrates:
- Advanced cryptographic protocol implementation
- Secure software development practices
- Real-world steganography applications
- PKI infrastructure design
- Web security principles

---
**CryptoSteg** - Advanced Steganography Tool for ST6051CEM Practical Cryptography