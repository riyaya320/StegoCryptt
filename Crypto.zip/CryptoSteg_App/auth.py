"""
CryptoSteg - Authentication Module
Advanced authentication system with cryptographic registration codes
"""

import os
import json
import hashlib
import secrets
import time
from datetime import datetime, timedelta
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import base64

class AuthManager:
    """Advanced Authentication Manager with cryptographic security"""
    
    def __init__(self):
        self.auth_db = {}
        self.active_sessions = {}
        self.registration_codes = {}
        self.failed_attempts = {}
        self.data_dir = "auth_data"
        os.makedirs(self.data_dir, exist_ok=True)
        self.load_auth_data()
        self.generate_master_codes()
    
    def generate_master_codes(self):
        """Generate master registration codes with cryptographic strength"""
        master_codes = [
            "ALPHA-7X9K-DELTA-3M8P",
            "BRAVO-2N5Q-ECHO-7R4T",
            "CHARLIE-9W6E-FOXTROT-1Y8U",
            "DELTA-4H3J-GOLF-6K9L",
            "ECHO-8V2B-HOTEL-5N7M"
        ]
        
        # Generate time-based codes (valid for 24 hours)
        current_time = int(time.time())
        daily_seed = hashlib.sha256(f"CRYPTOSTEG_DAILY_{current_time // 86400}".encode()).hexdigest()[:16]
        time_based_code = f"TEMPORAL-{daily_seed[:4].upper()}-{daily_seed[4:8].upper()}-{daily_seed[8:12].upper()}"
        
        # Store all valid codes
        for code in master_codes + [time_based_code]:
            code_hash = hashlib.sha256(code.encode()).hexdigest()
            self.registration_codes[code_hash] = {
                'code': code,
                'created': datetime.now().isoformat(),
                'uses': 0,
                'max_uses': 50 if code in master_codes else 10
            }
    
    def validate_registration_code(self, code):
        """Validate registration code with cryptographic verification"""
        code_hash = hashlib.sha256(code.upper().encode()).hexdigest()
        
        if code_hash in self.registration_codes:
            code_data = self.registration_codes[code_hash]
            if code_data['uses'] < code_data['max_uses']:
                code_data['uses'] += 1
                self.save_auth_data()
                return True, "Code validated successfully"
        
        return False, "Invalid or expired registration code"
    
    def derive_key(self, password, salt):
        """Derive encryption key from password using PBKDF2"""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
            backend=default_backend()
        )
        return kdf.derive(password.encode())
    
    def encrypt_password(self, password):
        """Encrypt password with AES-256-GCM"""
        salt = os.urandom(16)
        key = self.derive_key(password, salt)
        iv = os.urandom(12)
        
        cipher = Cipher(algorithms.AES(key), modes.GCM(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        ciphertext = encryptor.update(password.encode()) + encryptor.finalize()
        
        return base64.b64encode(salt + iv + encryptor.tag + ciphertext).decode()
    
    def verify_password(self, password, encrypted_password):
        """Verify password against encrypted version"""
        try:
            data = base64.b64decode(encrypted_password.encode())
            salt = data[:16]
            iv = data[16:28]
            tag = data[28:44]
            ciphertext = data[44:]
            
            key = self.derive_key(password, salt)
            cipher = Cipher(algorithms.AES(key), modes.GCM(iv, tag), backend=default_backend())
            decryptor = cipher.decryptor()
            decrypted = decryptor.update(ciphertext) + decryptor.finalize()
            
            return decrypted.decode() == password
        except:
            return False
    
    def register_user(self, username, password, registration_code, email=None):
        """Register new user with enhanced security"""
        # Validate registration code
        code_valid, code_message = self.validate_registration_code(registration_code)
        if not code_valid:
            return False, code_message
        
        # Check if user exists
        if username.lower() in self.auth_db:
            return False, "Agent codename already exists"
        
        # Validate password strength
        if len(password) < 8:
            return False, "Password must be at least 8 characters"
        
        # Create user account
        user_data = {
            'username': username,
            'password_hash': self.encrypt_password(password),
            'email': email,
            'created_at': datetime.now().isoformat(),
            'last_login': None,
            'login_count': 0,
            'security_level': 'CLASSIFIED',
            'two_factor_enabled': False,
            'account_locked': False,
            'failed_login_attempts': 0
        }
        
        self.auth_db[username.lower()] = user_data
        self.save_auth_data()
        
        return True, "Agent registration successful"
    
    def authenticate_user(self, username, password):
        """Authenticate user with enhanced security checks"""
        username_lower = username.lower()
        
        # Check if user exists
        if username_lower not in self.auth_db:
            return False, "Invalid credentials", None
        
        user_data = self.auth_db[username_lower]
        
        # Check if account is locked
        if user_data.get('account_locked', False):
            return False, "Account locked due to security violations", None
        
        # Check failed attempts
        if user_data.get('failed_login_attempts', 0) >= 5:
            user_data['account_locked'] = True
            self.save_auth_data()
            return False, "Account locked due to multiple failed attempts", None
        
        # Verify password
        if not self.verify_password(password, user_data['password_hash']):
            user_data['failed_login_attempts'] = user_data.get('failed_login_attempts', 0) + 1
            self.save_auth_data()
            return False, "Invalid credentials", None
        
        # Reset failed attempts on successful login
        user_data['failed_login_attempts'] = 0
        user_data['last_login'] = datetime.now().isoformat()
        user_data['login_count'] = user_data.get('login_count', 0) + 1
        
        # Generate session token
        session_token = secrets.token_urlsafe(32)
        session_data = {
            'username': username,
            'created': datetime.now().isoformat(),
            'expires': (datetime.now() + timedelta(hours=8)).isoformat(),
            'ip_address': None,  # Will be set by the calling function
            'user_agent': None
        }
        
        self.active_sessions[session_token] = session_data
        self.save_auth_data()
        
        return True, "Authentication successful", session_token
    
    def validate_session(self, session_token):
        """Validate session token"""
        if session_token not in self.active_sessions:
            return False, "Invalid session", None
        
        session_data = self.active_sessions[session_token]
        expires = datetime.fromisoformat(session_data['expires'])
        
        if datetime.now() > expires:
            del self.active_sessions[session_token]
            self.save_auth_data()
            return False, "Session expired", None
        
        return True, "Session valid", session_data['username']
    
    def logout_user(self, session_token):
        """Logout user and invalidate session"""
        if session_token in self.active_sessions:
            del self.active_sessions[session_token]
            self.save_auth_data()
            return True
        return False
    
    def get_user_profile(self, username):
        """Get user profile information"""
        username_lower = username.lower()
        if username_lower in self.auth_db:
            user_data = self.auth_db[username_lower].copy()
            del user_data['password_hash']  # Don't return password hash
            return user_data
        return None
    
    def get_registration_codes(self):
        """Get available registration codes (admin function)"""
        codes = []
        for code_hash, code_data in self.registration_codes.items():
            codes.append({
                'code': code_data['code'],
                'uses': code_data['uses'],
                'max_uses': code_data['max_uses'],
                'remaining': code_data['max_uses'] - code_data['uses']
            })
        return codes
    
    def save_auth_data(self):
        """Save authentication data to disk"""
        data = {
            'auth_db': self.auth_db,
            'active_sessions': self.active_sessions,
            'registration_codes': self.registration_codes,
            'failed_attempts': self.failed_attempts
        }
        with open(os.path.join(self.data_dir, 'auth_data.json'), 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_auth_data(self):
        """Load authentication data from disk"""
        try:
            with open(os.path.join(self.data_dir, 'auth_data.json'), 'r') as f:
                data = json.load(f)
                self.auth_db = data.get('auth_db', {})
                self.active_sessions = data.get('active_sessions', {})
                self.registration_codes = data.get('registration_codes', {})
                self.failed_attempts = data.get('failed_attempts', {})
        except FileNotFoundError:
            pass

# Global authentication instance
auth_manager = AuthManager()